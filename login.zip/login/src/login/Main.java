
package login;




public class Main {

    
    public static void main(String[] args) {
     inte login = new inte();
    
    }
    
}
