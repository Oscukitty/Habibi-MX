/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Tufic
 * Created: 31/01/2020
 */

package Metodos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class MetodosBD {
    
Pool metodospool = new Pool();
    
public int Guardar(String nombres, String apellidos, String email, String celular, 
                   String direccion, String sexo){

int resultado = 0;

Connection con = null;

String SSQL = "INSERT INTO contacto (nombres, apellidos, email, celular, direccion, sexo) "
            + "VALUES (?, ?, ?, ?, ?, ?)";


    try {
    
        con = metodospool.dataSource.getConnection();
        
        PreparedStatement psql = con.prepareStatement(SSQL);
        psql.setString(1, nombres);
        psql.setString(2, apellidos);
        psql.setString(3, email);
        psql.setString(4, celular);
        psql.setString(5, direccion);
        psql.setString(6, sexo);
        
        resultado = psql.executeUpdate();
        
        psql.close();
                    
    } catch (SQLException e) {
    
        JOptionPane.showMessageDialog(null, "Error al intentar almacenar la información:\n"
                                     + e, "Error en la operación", JOptionPane.ERROR_MESSAGE);
        
    }finally{
    
        try {
            
            if(con!=null){
            
                con.close();
                
            }
            
        } catch (SQLException ex) {
        
            JOptionPane.showMessageDialog(null, "Error al intentar cerrar la conexión:\n"
                                     + ex, "Error en la operación", JOptionPane.ERROR_MESSAGE);
            
        }
    
    }

    return resultado;
    
}    
    
    
    
}
      